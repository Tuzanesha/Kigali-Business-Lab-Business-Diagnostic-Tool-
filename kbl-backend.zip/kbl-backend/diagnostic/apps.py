from django.apps import AppConfig


class DiagnosticConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'diagnostic'
